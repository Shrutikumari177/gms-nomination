sap.ui.define(["sap/ui/core/mvc/Controller"],n=>{"use strict";return n.extend("com.ingenx.nomination.salesnomination.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map